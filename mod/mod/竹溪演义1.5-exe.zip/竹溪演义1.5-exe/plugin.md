# Cassia Seedling Studios - 插件系统开发文档

## 概述

本游戏采用 **运行时动态加载** 的插件系统。插件以 **动态链接库（.dll）** 的形式存在，游戏启动时会自动扫描 `plugins/` 文件夹并加载所有符合接口规范的插件。

**插件系统的优点：**
- 无需重新编译游戏主程序
- 可以随时添加、删除、更新插件
- 插件之间互相隔离，不会影响游戏核心稳定性

---

## 插件系统架构
zxxy/
├── plugins/ # 存放编译好的插件 .dll 文件
├── plugin/
│ ├── plugin.h # 插件接口定义（游戏侧）
│ ├── plugin_manager.c # 插件管理器
│ ├── plugin_loader.c # 动态加载器（扫描 plugins/ 文件夹）
│ └── my_plugin/ # 插件项目文件夹（独立编译）
│ ├── my_plugin.c # 插件源码
│ └── CMakeLists.txt # 插件独立的 CMake 编译配置
├── main.c # 游戏主入口（调用插件系统）
└── CMakeLists.txt # 游戏主 CMake 配置（不包含插件）

---

## 插件接口 (Plugin API)

每个插件必须实现以下 **导出函数**（`EXPORT` 宏）：

| 函数名 | 返回值 | 参数 | 说明 |
|--------|--------|------|------|
| `GetPluginInfo` | `PluginInfo` | 无 | 返回插件的基本信息（名称、版本、作者、描述） |
| `OnPluginLoad` | `void` | 无 | 插件加载时调用，用于初始化 |
| `OnPluginUnload` | `void` | 无 | 插件卸载时调用，用于清理资源 |
| `OnPluginUpdate` | `void` | `float deltaTime` | 每帧调用，用于更新逻辑 |
| `OnPluginDraw` | `void` | 无 | 每帧调用，用于绘制 UI |
| `OnPluginEvent` | `bool` | `const char* event, void* data` | 事件处理，返回 `true` 表示已处理 |

### 数据结构定义

```c
// plugin.h 中定义
typedef struct {
    char name[64];      // 插件名称
    char version[16];   // 版本号
    char author[64];    // 作者
    char description[256]; // 插件描述
} PluginInfo;
开发一个新插件（完整示例）
1. 创建插件项目目录
在 plugin/ 下新建一个文件夹，例如 my_plugin/：

text
复制
下载
plugin/my_plugin/
├── my_plugin.c
└── CMakeLists.txt
2. 编写插件源码 my_plugin.c
c
复制
下载
#include <stdio.h>
#include <string.h>

// 游戏侧提供的插件接口
#include "../plugin.h"

// 导出宏（Windows 下导出 DLL 符号）
#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

// 插件状态（如果需要）
static bool enabled = true;
static float timer = 0.0f;

// ---- 插件生命周期函数 ----

// 插件信息
EXPORT PluginInfo GetPluginInfo(void) {
    PluginInfo info = {
        .name = "MyPlugin",
        .version = "1.0.0",
        .author = "Cassia Seedling",
        .description = "一个示例插件"
    };
    return info;
}

// 加载时调用
EXPORT void OnPluginLoad(void) {
    printf("🔧 示例插件已加载\n");
}

// 卸载时调用
EXPORT void OnPluginUnload(void) {
    printf("🔧 示例插件已卸载\n");
}

// 每帧更新
EXPORT void OnPluginUpdate(float deltaTime) {
    timer += deltaTime;
    // 你的更新逻辑...
}

// 每帧绘制
EXPORT void OnPluginDraw(void) {
    // 你的绘制逻辑...
    DrawText("MyPlugin is running", 10, 10, 20, WHITE);
}

// 事件处理
EXPORT bool OnPluginEvent(const char* event, void* data) {
    if (strcmp(event, "key_pressed") == 0) {
        int key = *(int*)data;
        if (key == KEY_F1) {
            enabled = !enabled;
            return true;
        }
    }
    return false;
}
3. 编写插件的 CMakeLists.txt
cmake
复制
下载
cmake_minimum_required(VERSION 3.10)
project(my_plugin)

# 设置输出目录为游戏的主插件目录
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_SOURCE_DIR}/../../plugins)

# 头文件路径
include_directories(${CMAKE_SOURCE_DIR}/../..)
include_directories(${CMAKE_SOURCE_DIR}/../../../raylib/src)

# 编译成动态库（.dll）
add_library(my_plugin SHARED my_plugin.c)

# 链接 raylib（插件需要用到 raylib 绘图函数）
target_link_libraries(my_plugin raylib)
4. 编译插件
在插件目录下运行：

bash
复制
下载
mkdir build && cd build
cmake ..
cmake --build . --config Release
编译完成后，在 plugins/ 文件夹下会生成 my_plugin.dll。

游戏侧提供的 API
插件可以调用以下游戏函数：

函数	说明
PluginManager_GetPlayer()	获取当前玩家指针
PluginManager_GetHouse()	获取房子指针
PluginManager_GetWorldItems(int* count)	获取世界物品列表
TryPickupItem(Player* player, WorldItem* item)	尝试拾取物品
AddItemToInventory(Player* player, ItemType type, int count)	向背包添加物品
GetItemDef(ItemType type)	获取物品定义
GetItemTexture(ItemType type)	获取物品贴图
插件开发规范
插件必须导出所有 OnPluginXXX 函数，否则不会被加载。

插件不要直接修改游戏核心数据结构，尽量通过提供的 API 进行操作。

插件之间不要互相依赖，保持独立。

插件应尽量减小内存占用，避免影响游戏性能。

插件应妥善处理资源加载和卸载，避免内存泄漏。

事件系统
游戏会向所有插件广播事件：

事件名	数据类型	说明
"key_pressed"	int*	按键事件，传递按键码
插件可以通过 OnPluginEvent 函数处理事件，返回 true 表示已处理。

常见问题
Q: 为什么我的插件没有被加载？
A: 检查 plugins/ 文件夹下是否有 .dll 文件，以及是否导出了所有必需的函数。

Q: 插件可以使用哪些库？
A: 插件可以使用 raylib 的所有绘图和输入函数，但不能使用游戏内部未导出的函数。

Q: 插件之间会发生冲突吗？
A: 不会。每个插件都是独立的 DLL，游戏按顺序加载它们，不会互相影响。

Q: 如何调试插件？
A: 在插件代码中加入 printf 输出，或者使用 raylib 的 TraceLog 输出调试信息。

扩展阅读
Raylib 官方文档

CMake 官方文档

Windows 动态链接库开发指南

---

## 保存方式

将上面的内容保存为 `PLUGIN.md` 文件，放在你的项目根目录 `zxxy/` 下面即可。

---

## 后续扩展计划

如果你想让插件系统支持 **“添加新物品”** 或 **“添加新合成配方”** 等更高级的功能，我可以在下一版中为你扩展：
1. **物品注册系统**：允许插件通过 API 注册新物品类型，游戏自动识别并加载贴图。
2. **合成配方扩展**：允许插件向游戏注册新的合成配方。

